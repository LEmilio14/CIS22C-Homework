#include "Dollar.h"

Dollar::~Dollar()
{

}