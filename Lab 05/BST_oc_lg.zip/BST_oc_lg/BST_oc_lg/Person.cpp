#include "Person.h"

Person::Person(std::string n, std::string b) : name(n), birthday(b)
{

}

Person::~Person()
{

}