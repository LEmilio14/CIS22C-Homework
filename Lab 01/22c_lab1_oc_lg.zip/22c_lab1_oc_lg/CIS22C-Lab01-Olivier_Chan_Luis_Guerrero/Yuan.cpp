#include "Yuan.h"

Yuan::~Yuan()
{

}