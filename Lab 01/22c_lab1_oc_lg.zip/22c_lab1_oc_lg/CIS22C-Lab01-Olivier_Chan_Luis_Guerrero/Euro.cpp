#include "Euro.h"

Euro::~Euro()
{

}