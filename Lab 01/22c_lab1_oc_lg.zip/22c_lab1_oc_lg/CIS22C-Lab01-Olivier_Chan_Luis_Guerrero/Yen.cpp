#include "Yen.h"

Yen::~Yen()
{

}